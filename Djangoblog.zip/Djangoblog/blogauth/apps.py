from django.apps import AppConfig


class BlogauthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blogauth'
