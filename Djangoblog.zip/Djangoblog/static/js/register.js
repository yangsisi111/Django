$(function() {
    function bindCaptchaBtnClick() {
        $("#captcha-btn").click(function(event) {
            let $this = $(this);
            let email = $("input[name='email']").val();
            if (!email) {
                alert("请先输入邮箱!");
                return;
            }
            // 取消按钮的点击事件
            $this.off('click');

            // 获取 CSRF Token
            let csrfToken = $("meta[name='csrf-token']").attr("content");

            // 发送 AJAX 请求
            $.ajax('/auth/captcha?email=' + email, {
                method: 'GET',
                headers: {
                    'X-CSRFToken': csrfToken  // 添加 CSRF Token
                },
                success: function(result) {
                    if(result['code'] == 200){
                        alert("验证码发送成功!")
                    }else {
                        alert(result['message']);
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });

            // 倒计时
            let countdown = 60;
            let timer = setInterval(function() {
                if (countdown <= 0) {
                    $this.text('获取验证码');
                    clearInterval(timer);
                    setTimeout(bindCaptchaBtnClick, 100);  // 延迟一小段时间重新绑定
                } else {
                    countdown--;
                    $this.text(countdown + "s");
                }
            }, 1000);
        });
    }
    bindCaptchaBtnClick();
});
